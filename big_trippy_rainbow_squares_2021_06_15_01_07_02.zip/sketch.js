

function setup() {
  
createCanvas(800, 800);
background(220);
}

function draw() {
  let c = color(Math.floor(Math.random() * 1000),   mouseX /2, mouseY/2)
  rect(mouseX, mouseY, mouseX, mouseY)
  fill(c)
}